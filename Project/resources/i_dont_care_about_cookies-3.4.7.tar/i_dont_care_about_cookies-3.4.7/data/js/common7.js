var a = document.getElementById('ctl00_ctl01_ucCookieCheck_btnConfirm');

if (a)
{
	document.getElementById('ctl00_ctl01_ucCookieCheck_rblAllowCookies_0').click();
	a.click();
}